<?php

$pdo = new PDO(
    'mysql:host=localhost;dbname=soa_2025;port=3306',
    'root', 
    '');



// INSTRUÇÃO SQL DE CONSULTA
// $sql = 'SELECT * FROM produto WHERE registro = 1';
// $stm = $pdo->prepare($sql);
// $stm->execute();
// $registros = $stm->fetchAll(PDO::FETCH_OBJ);



// INSTRUÇÃO SQL DE CONSULTA PARAMETRIZADA
// $sql = 'SELECT * FROM produto WHERE status = ?';
// $stm = $pdo->prepare($sql);
// $stm->execute(['Ativo']);
// $registros = $stm->fetchAll(PDO::FETCH_OBJ);

// var_dump($registros);

// foreach($registros as $chave => $valor) {
//     echo "Produto " . $valor->descricao . "<br>";
// } // deixa mais organizado para ver



// INSTRUÇÃO SQL DE INSERÇÃO PARAMETRIZADA
// $sql = 'INSERT INTO produto(descricao, valor, status) VALUES (?, ?, ?)';
// $stm = $pdo->prepare($sql);
// $sucesso = $stm->execute(['PRODUTO TESTE', 100.00, 'ATIVO']);

// if($sucesso) {
//     echo "Produto inserido com sucesso.";
// } else {
//     echo "Erro ao inserir produto.";
// }



// INSTRUÇÃO SQL DE UPDATE PARAMETRIZADA
// $sql = 'UPDATE produto SET descricao = ?, valor = ?, status = ? WHERE id = ?';
// $stm = $pdo->prepare($sql);
// $sucesso = $stm->execute(['PRODUTO EDITADO', 100.00, 'ATIVO', 1]);

// if($sucesso) {
//     echo "Produto atualizado com sucesso.";
// } else {
//     echo "Erro ao atualizar produto.";
// }



// INSTRUÇÃO SQL DE DELETE PARAMETRIZADA
// $sql = 'DELETE FROM produto WHERE id = ?';
// $stm = $pdo->prepare($sql);
// $sucesso = $stm->execute([1]);

// if($sucesso) {
//     echo "Produto excluído com sucesso.";
// } else {
//     echo "Erro ao excluir produto.";
// }



// INSTRUÇÃO SQL DE EXCLUSÃO LÓGICA PARAMETRIZADA
$sql = 'UPDATE produto SET registro = ? WHERE id = ?';
$stm = $pdo->prepare($sql);
$sucesso = $stm->execute([0, 2]);

if($sucesso) {
    echo "Produto excluído com sucesso.";
} else {
    echo "Erro ao excluir produto.";
}



// CRTL + ; para comentar/descomentar

?>