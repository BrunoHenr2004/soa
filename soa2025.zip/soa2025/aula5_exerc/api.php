<?php

$pdo = new PDO(
    'mysql:host=localhost;dbname=soa_2025;port=3306',
    'root',
    '');

    if($_SERVER['REQUEST_METHOD'] == 'GET') {

        // INSTRUÇÃO SQL DE CONSULTA PARAMETRIZADA
        $sql = 'SELECT * FROM usuario';
        $stm = $pdo->prepare($sql);
        $stm->execute();
        $registros = $stm->fetchAll(PDO::FETCH_OBJ);

        echo json_encode(['usuários' => $registros]);
    }



    if($_SERVER['REQUEST_METHOD'] == 'POST') {

        // RECEPÇÃO DOS DADOS VIA POST
        $descricao = (isset($_POST['nome_produto'])) ? $_POST['nome_produto'] : '';
        $valor = (isset($_POST['valor'])) ? $_POST['valor'] : '0';
        $status = (isset($_POST['status'])) ? $_POST['status'] : '';
        $registro = (isset($_POST['registro'])) ? $_POST['registro'] : '';
        $grupo = (isset($_POST['grupo'])) ? $_POST['grupo'] : '';

        // VALIDAR INPUT DO USUÁRIO
        if(!is_float($valor + 0) || $valor <= 0) {
            echo json_encode(['mensagem' => 'Valor inválido!']);
            http_response_code(406);
            exit;
        }

        if(strlen($descricao) < 3) {
            echo json_encode(['mensagem' => 'Descrição inválida!']);
            http_response_code(406);
            exit;
        }

        // VALIDAÇÕES EM NÍVEL DE BANCO DE DADOS
        $sql = 'SELECT * FROM produto WHERE descricao = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$descricao]);
        $produto = $stm->fetchAll(PDO::FETCH_OBJ);

        if(!empty($produto)) {
            echo json_encode(['mensagem' => 'Produto já cadastrado']);
            http_response_code(406);
            exit;
        }

        // VERIFICAÇÃO DA EXISTÊNCIA DO GRUPO
        $sql = 'SELECT id FROM grupo WHERE descricao = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$grupo]);
        $dadosGrupo = $stm->fetchAll(PDO::FETCH_OBJ);

        $idGrupo = 0;

        if(!empty($dadosGrupo)) {
            $idGrupo = $dadosGrupo[0]->id;
        } else {
            $sql = 'INSERT INTO grupo (descricao, status) VALUES (?, ?)';
            $stm = $pdo->prepare($sql);
            $stm->execute([$grupo, 'ATIVO']);
            
            $sql = 'SELECT id FROM grupo WHERE descricao = ?';
            $stm = $pdo->prepare($sql);
            $stm->execute([$grupo]);
            $dadosGrupo = $stm->fetchAll(PDO::FETCH_OBJ);

            $idGrupo = $dadosGrupo[0]->id;
        }

        // INSTRUÇÃO SQL DE INSERÇÃO PARAMETRIZADA
        $sql = 'INSERT INTO produto (descricao, valor, status, registro, grupo_id) VALUES (?, ?, ?, ?, ?)';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$descricao, $valor, $status, $registro, $idGrupo]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Inserido com sucesso']);
            http_response_code(201);
        } else {
            echo json_encode(['mensagem' => 'Falha ao inserir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form Data"
    }



    if($_SERVER['REQUEST_METHOD'] == 'PUT') {
        parse_str(file_get_contents('php://input') ?? '', $_PUT);
        
        $descricao = (isset($_PUT['nome_produto'])) ? $_PUT['nome_produto'] : '';
        $valor = (isset($_PUT['valor'])) ? $_PUT['valor'] : '';
        $status = (isset($_PUT['status'])) ? $_PUT['status'] : '';
        $registro = (isset($_PUT['id'])) ? $_PUT['id'] : '';

        // INSTRUÇÃO SQL DE UPDATE PARAMETRIZADA
        $sql = 'UPDATE produto SET descricao = ?, valor = ?, status = ? WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$descricao, $valor, $status, $registro]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Atualizado com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao atualizar']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form URL Encoded"
    }



    if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
        $id = (isset($_REQUEST['id'])) ? $_REQUEST['id'] : '';

        // INSTRUÇÃO SQL DE DELETE PARAMETRIZADA
        $sql = 'DELETE FROM produto WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$id]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Excluído com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao excluir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via URL
    }

?>