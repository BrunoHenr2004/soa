<?php

$pdo = new PDO(
    'mysql:host=localhost;dbname=soa_2025;port=3306',
    'root', 
    '');

    if($_SERVER['REQUEST_METHOD'] == 'GET') {

        $registro = (isset($_GET['registro'])) ? $_GET['registro'] : '';
        $privilegio = (isset($_GET['privilegio'])) ? $_GET['privilegio'] : '';

        if($privilegio = 'admin') {
            echo json_encode(['mensagem' => 'O usuário não tem essa permissão']);
            http_response_code(200);

            exit;
        }

        // INSTRUÇÃO SQL DE CONSULTA PARAMETRIZADA
        $sql = 'SELECT * FROM produto WHERE registro = 1';
        $stm = $pdo->prepare($sql);
        $stm->execute();
        $registros = $stm->fetchAll(PDO::FETCH_OBJ);

        echo json_encode(['produtos' => $registros]);
    }



    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        $nome_produto = (isset($_POST['nome_produto'])) ? $_POST['nome_produto'] : '';
        $preco = (isset($_POST['preco'])) ? $_POST['preco'] : '';
        $status = (isset($_POST['status'])) ? $_POST['status'] : '';
        $registro = (isset($_POST['registro'])) ? $_POST['registro'] : '';

        // INSTRUÇÃO SQL DE INSERÇÃO PARAMETRIZADA
        $sql = 'INSERT INTO produto (descricao, valor, status, registro) VALUES (?, ?, ?, ?)';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$nome_produto, $preco, $status, $registro]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Inserido com sucesso']);
            http_response_code(201);
        } else {
            echo json_encode(['mensagem' => 'Falha ao inserir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form Data"
    }



    if($_SERVER['REQUEST_METHOD'] == 'PUT') {
        parse_str(file_get_contents('php://input') ?? '', $_PUT);
        
        $a = (isset($_PUT['nome_produto'])) ? $_PUT['nome_produto'] : '';
        $b = (isset($_PUT['preco'])) ? $_PUT['preco'] : '';
        $c = (isset($_PUT['status'])) ? $_PUT['status'] : '';
        $d = (isset($_PUT['id'])) ? $_PUT['id'] : '';

        // INSTRUÇÃO SQL DE UPDATE PARAMETRIZADA
        $sql = 'UPDATE produto SET descricao = ?, valor = ?, status = ? WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$a, $b, $c, $d]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Atualizado com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao atualizar']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form URL Encoded"
    }

    

    if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
        $id = (isset($_REQUEST['id'])) ? $_REQUEST['id'] : '';

        // INSTRUÇÃO SQL DE DELETE PARAMETRIZADA
        $sql = 'DELETE FROM produto WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$id]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Excluído com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao excluir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via URL
    }

?>