<?php

$pdo = new PDO(
    'mysql:host=localhost;dbname=teste;port=3306',
    'root',
    '');

    $headers = getallheaders();
    $cript = $headers['Authorization'];
    $stringLimpa = str_replace('Basic ', '', $cript);
    $dados = base64_decode($stringLimpa);
    list($email, $senha) = explode(':', $dados);
    // echo $email . ' - ' . $senha;

    if($_SERVER['REQUEST_METHOD'] == 'GET') {

        // VALIDAÇÕES EM NÍVEL DE BANCO DE DADOS
        $sql = 'SELECT * FROM usuario WHERE email = ? AND senha = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$email, $senha]);
        $usuario = $stm->fetch(PDO::FETCH_OBJ);

        if($usuario && isset($usuario->consulta) && $usuario->consulta == 0) {
            echo json_encode(['mensagem' => 'Usuário não autorizado!']);
            http_response_code(401);
            exit;
        }

        if($usuario) {
            echo json_encode(['mensagem' => 'E-mail ou senha já existente!']);
            http_response_code(406);
            exit;
        }        

        // No Insomnia, passar parâmetro via Auth "Basic"
    }



    if($_SERVER['REQUEST_METHOD'] == 'POST') {

        // VALIDAÇÕES DO USUÁRIO EM NÍVEL DE BANCO DE DADOS
        $sql = 'SELECT * FROM usuario WHERE email = ? AND senha = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$email, $senha]);
        $usuario = $stm->fetch(PDO::FETCH_OBJ);

        if(empty($usuario)) {
            echo json_encode(['mensagem' => 'Usuário não encontrado!']);
            http_response_code(404);
            exit;
        }

        if(!empty($usuario->insercao == 0)) {
            echo json_encode(['mensagem' => 'Usuário não autorizado!']);
            http_response_code(401);
            exit;
        }

        // No Insomnia, passar parâmetro via Auth "Basic"

        // RECEPÇÃO DOS DADOS VIA POST
        $descricao = (isset($_POST['nome_jogo'])) ? $_POST['nome_jogo'] : '';
        $valor = (isset($_POST['valor'])) ? $_POST['valor'] : '0';
        $ano = (isset($_POST['ano'])) ? $_POST['ano'] : '';
        $categoria = (isset($_POST['categoria'])) ? $_POST['categoria'] : '';

        // VALIDAR INPUT DO USUÁRIO
        if(!is_float($valor + 0) || $valor <= 0) {
            echo json_encode(['mensagem' => 'Valor inválido!']);
            http_response_code(406);
            exit;
        }

        if(strlen($descricao) < 3) {
            echo json_encode(['mensagem' => 'Descrição inválida!']);
            http_response_code(406);
            exit;
        }

        if(!preg_match('/^\d{4}$/', $ano)) {
            echo json_encode(['mensagem' => 'Ano de lançamento inválido! Deve conter exatamente 4 dígitos numéricos.']);
            http_response_code(406);
            exit;
        }

        // VALIDAÇÕES DO JOGO EM NÍVEL DE BANCO DE DADOS
        $sql = 'SELECT * FROM jogo WHERE descricao = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$descricao]);
        $jogo = $stm->fetchAll(PDO::FETCH_OBJ);

        if(!empty($jogo)) {
            echo json_encode(['mensagem' => 'Jogo já cadastrado']);
            http_response_code(406);
            exit;
        }

        // VERIFICAÇÃO DA EXISTÊNCIA DA CATEGORIA
        $sql = 'SELECT id FROM categoria WHERE descricao = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$categoria]);
        $dadosCategoria = $stm->fetchAll(PDO::FETCH_OBJ);

        $idCategoria = 0;

        if(!empty($dadosCategoria)) {
            $idCategoria = $dadosCategoria[0]->id;
        } else {
            $sql = 'INSERT INTO categoria(descricao, status) VALUES (?, ?)';
            $stm = $pdo->prepare($sql);
            $stm->execute([$categoria, 'ATIVO']);
            
            $sql = 'SELECT id FROM categoria WHERE descricao = ?';
            $stm = $pdo->prepare($sql);
            $stm->execute([$categoria]);
            $dadosCategoria = $stm->fetchAll(PDO::FETCH_OBJ);

            $idCategoria = $dadosCategoria[0]->id;
        }

        // INSTRUÇÃO SQL DE INSERÇÃO PARAMETRIZADA
        $sql = 'INSERT INTO jogo(descricao, valor, ano_lancamento, categoria_id) VALUES (?, ?, ?, ?)';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$descricao, $valor, $ano, $idCategoria]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Inserido com sucesso']);
            http_response_code(201);
        } else {
            echo json_encode(['mensagem' => 'Falha ao inserir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form Data"
    }



    if($_SERVER['REQUEST_METHOD'] == 'PUT') {
        parse_str(file_get_contents('php://input') ?? '', $_PUT);

        // VALIDAÇÕES EM NÍVEL DE BANCO DE DADOS
        $sql = 'SELECT * FROM usuario WHERE email = ? AND senha = ?';
        $stm = $pdo->prepare($sql);
        $stm->execute([$email, $senha]);
        $usuario = $stm->fetch(PDO::FETCH_OBJ);

        if(empty($usuario)) {
            echo json_encode(['mensagem' => 'Usuário não encontrado!']);
            http_response_code(404);
            exit;
        }

        if(!empty($usuario->atualizacao == 0)) {
            echo json_encode(['mensagem' => 'Usuário não autorizado!']);
            http_response_code(401);
            exit;
        }
        
        // RECEPÇÃO DOS DADOS VIA PUT
        $descricao = (isset($_PUT['nome_jogo'])) ? $_PUT['nome_jogo'] : '';
        $valor = (isset($_PUT['valor'])) ? $_PUT['valor'] : '';
        $ano = (isset($_PUT['ano'])) ? $_PUT['ano'] : '';
        $id = (isset($_PUT['id'])) ? $_PUT['id'] : '';

        // INSTRUÇÃO SQL DE UPDATE PARAMETRIZADA
        $sql = 'UPDATE jogo SET descricao = ?, valor = ?, ano_lancamento = ? WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$descricao, $valor, $ano, $id]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Atualizado com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao atualizar']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form URL Encoded"
    }



    if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
        $id = (isset($_REQUEST['id'])) ? $_REQUEST['id'] : '';

        // INSTRUÇÃO SQL DE DELETE PARAMETRIZADA
        $sql = 'DELETE FROM jogo WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$id]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Excluído com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao excluir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via URL
    }

?>