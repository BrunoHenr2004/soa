<?php

if($_SERVER['REQUEST_METHOD'] == 'GET') {
    $codigo = (isset($_GET['codigo'])) ? $_GET['codigo'] : '';

    if($codigo == '') {
        echo json_encode(['status' => 406, 'mensagem' => 'Parâmetro codigo obrigatório']);
        http_response_code(406);
        exit;
    }

    if(!is_numeric ($codigo)) {
        echo json_encode(['status' => 406, 'mensagem' => 'Parâmetro deve ser numérico']);
        http_response_code(406);
        exit;
    }

    if(strlen($codigo) != 13){
        echo json_encode(['status' => 406, 'mensagem' => 'Parâmetro código deve ter 13 números']);
        http_response_code(406);
        exit;
    }

    echo json_encode(['status' => 200, 'mensagem' => 'Gravado com sucesso']);
    http_response_code(200); // status code

}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = (isset ($_POST['nome'])) ? $_POST ['nome'] : '';
    $cpf = (isset ($_POST['cpf'])) ? $_POST ['cpf'] : '';
    $rua = (isset ($_POST['rua'])) ? $_POST ['rua'] : '';
    $numero = (isset ($_POST['numero'])) ? $_POST ['numero'] : '';

    try {
        if($nome == '')
            throw new Exception('Campo obrigatório');         
        if(!str_contains ($nome, ' ') == $nome)
            throw new Exception('Deve ser um nome composto');
        if(strlen($nome) <= 20)
            throw new Exception('Minimo de 20 caracteres');
        if(strlen($cpf) != 11)
            throw new Exception('Campo deve ter 11 caracteres');
        if($rua == '')
            throw new Exception('Campo obrigatório');
        if(!str_contains ($rua, ' ') == $rua)
            throw new Exception('Deve ser um nome composto');
        if(strlen($rua) <= 20)
        throw new Exception('Campo deve ter 11 caracteres');
        if(!is_numeric ($numero))
        throw new Exception('Digite apenas números');
        
        http_response_code(201);
        echo json_encode(['status' => 201, 'mensagem' => 'Gravado com sucesso', 'nome' => $nome, 'cpf' => $cpf, 'rua' => $rua, 'numero' => $numero]);
        
    } catch(\Exception $th) {
        echo json_encode(['status' => 406, 'mensagem' => $th -  > getMessage()]);
    }
}

//     if($nome == ''){
//         echo json_encode (['status' => 406, 'mensagem' => 'Campo obrigatório']);
//         http_response_code(406);
//         exit;
//     }

//     if(!str_contains ($nome, ' ') == $nome){
//         echo json_encode(['status' => 406, 'mensagem' => 'Deve ser um nome composto']);
//         http_response_code(406);
//         exit;
 
//     }
//     if(strlen($nome) <= 20){
//         echo json_encode(['status' => 406, 'mensagem' => 'Mínimo de caracteres atingido']);
//         http_response_code(406);
//         exit;
//     }

//     $cpf = str_replace([',', '-', '.', '*', ' '], '', $cpf);

//     if(strlen($cpf) != 11){
//         echo json_encode(['status' => 406, 'mensagem' => 'Parâmetro código deve ter 11 números']);
//         http_response_code(406);
//         exit;
//     }

//     if($rua == ''){
//         echo json_encode (['status' => 406, 'mensagem' => 'Campo obrigatório']);
//         http_response_code(406);
//         exit;
//     }

//     if(!str_contains ($rua, ' ') == $rua){
//         echo json_encode(['status' => 406, 'mensagem' => 'Deve ser um nome composto']);
//         http_response_code(406);
//         exit;
 
//     }
//     if(strlen($rua) <= 20){
//         echo json_encode(['status' => 406, 'mensagem' => 'Mínimo de caracteres atingido']);
//         http_response_code(406);
//         exit;
//     }

//     if(!is_numeric ($numero)) {
//         echo json_encode(['status' => 406, 'mensagem' => 'Digite apenas números']);
//         http_response_code(406);
//         exit;
//     }


// http_response_code(201);
// echo json_encode(['status' => 201, 'mensagem' => 'Gravado com sucesso', 'nome' => $nome, 'cpf' => $cpf, 'rua' => $rua, 'numero' => $numero]);
// }

// if($_SERVER['REQUEST_METHOD'] == 'PUT') {
// http_response_code(202);
// echo json_encode(['status' => 202, 'mensagem' => 'Editado com sucesso']);
// }

// if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
// http_response_code(202);
// echo json_encode(['status' => 201, 'mensagem' => 'Excluído com sucesso']);
// }

// CRTL + ; para comentar/descomentar

?>