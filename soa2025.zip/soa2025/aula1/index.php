<?php 

// echo   '<pre>';
// print_r($_SERVER);


if($_SERVER['REQUEST_METHOD'] == 'GET') {
    $cod =(isset( $_GET['codigo'])) ? $_GET ['codigo']: '';
    $ean13 = $_GET['gtin'];

    echo "$cod - $ean13";

    // echo json_encode(['status' => 200, 'menssagem' => 'Consultado com sucesso']);
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo json_encode(['status' => 201, 'menssagem' => 'Gravado com sucesso']);
    http_response_code(201);
}

if($_SERVER['REQUEST_METHOD'] == 'PUT') {
    echo json_encode(['status' => 202, 'menssagem' => 'Alterado com sucesso']);
    http_response_code(202);
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    echo json_encode(['status' => 202, 'menssagem' => 'Deletado com sucesso']);
    http_response_code(202);
}

// CRTL + ; para comentar/descomentar

?>