<?php

$pdo = new PDO(
    'mysql:host=localhost;dbname=soa_2025;port=3306',
    'root', 
    '');

    if($_SERVER['REQUEST_METHOD'] == 'GET') {

        $id = (isset($_GET['id'])) ? $_GET['di'] : '';

        // INSTRUÇÃO SQL DE CONSULTA PARAMETRIZADA
        $sql = 'SELECT * FROM grupo';
        $stm = $pdo->prepare($sql);
        $stm->execute();
        $id = $stm->fetchAll(PDO::FETCH_OBJ);

        echo json_encode(['grupos' => $id]);
        http_response_code(200);
    }



    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        $descricao = (isset($_POST['nome_grupo'])) ? $_POST['nome_grupo'] : '';
        $status = (isset($_POST['status'])) ? $_POST['status'] : '';

        // INSTRUÇÃO SQL DE INSERÇÃO PARAMETRIZADA
        $sql = 'INSERT INTO grupo (descricao, status) VALUES (?, ?)';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$descricao, $status]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Inserido com sucesso']);
            http_response_code(201);
        } else {
            echo json_encode(['mensagem' => 'Falha ao inserir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form Data"
    }



    if($_SERVER['REQUEST_METHOD'] == 'PUT') {
        parse_str(file_get_contents('php://input') ?? '', $_PUT);
        
        $descricao = (isset($_PUT['nome_grupo'])) ? $_PUT['nome_grupo'] : '';
        $status = (isset($_PUT['status'])) ? $_PUT['status'] : '';
        $id = (isset($_PUT['id'])) ? $_PUT['id'] : '';

        // INSTRUÇÃO SQL DE UPDATE PARAMETRIZADA
        $sql = 'UPDATE grupo SET descricao = ?, status = ? WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$descricao, $status, $id]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Atualizado com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao atualizar']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via Body "Form URL Encoded"
    }



    if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
        $id = (isset($_REQUEST['id'])) ? $_REQUEST['id'] : '';

        // INSTRUÇÃO SQL DE DELETE PARAMETRIZADA
        $sql = 'DELETE FROM grupo WHERE id = ?';
        $stm = $pdo->prepare($sql);
        $sucesso = $stm->execute([$id]);

        if($sucesso) {
            echo json_encode(['mensagem' => 'Excluído com sucesso']);
            http_response_code(202);
        } else {
            echo json_encode(['mensagem' => 'Falha ao excluir']);
            http_response_code(500);
        }

        // No Insomnia, passar parâmetro via URL
    }

?>